'use strict';

/**
 * @ngdoc service
 * @name webPlayerMiniAppApp.ShareCtrl
 * @description
 * # ShareCtrl
 * Service in the webPlayerMiniAppApp.
 */
angular.module('webPlayerMiniAppApp')
  .factory('share', [function () {
    var share = {};

    share.fb = function(){


    };

    share.flagTheEpisode = function(){


    };

    return share;

  }]);

'use strict';

/**
 * @ngdoc function
 * @name webPlayerMiniAppApp.controller:AppCtrl
 * @description
 * # AppCtrl
 * Controller of the webPlayerMiniAppApp
 */
angular.module('webPlayerMiniAppApp')
    .controller('AppCtrl', [function () {

    // do validation on station id and origin url
    // if valid radio service is usable, else $scope.infoPanel = "error or not valid";

}]);
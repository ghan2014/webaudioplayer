'use strict';
var LIVE365PLAYER = LIVE365PLAYER || {};
1.1.0 / 2015-06-24
=================
  * Add a "shim" method
  * Add `npm run eslint`
  * Test latest `node` and `io.js` on `travis-ci`
  * Add license and download badges to README
  * Update `tape`, `covert`, `jscs`

1.0.1 / 2014-07-05
=================
  * Oops, jscs should be a devDependency

1.0.0 / 2014-07-05
=================
  * Initial release.

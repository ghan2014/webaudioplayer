module.exports = function(v) {
  return v === null;
};

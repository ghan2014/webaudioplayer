'use strict';

var bin = require('./lib');

/**
 * Module exports
 */

module.exports.path = bin.path();

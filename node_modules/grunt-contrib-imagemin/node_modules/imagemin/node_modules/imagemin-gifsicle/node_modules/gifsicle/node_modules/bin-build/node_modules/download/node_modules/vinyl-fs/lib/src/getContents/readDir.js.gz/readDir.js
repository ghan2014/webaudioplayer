'use strict';

function readDir(file, cb) {
  // do nothing for now
  cb(null, file);
}

module.exports = readDir;

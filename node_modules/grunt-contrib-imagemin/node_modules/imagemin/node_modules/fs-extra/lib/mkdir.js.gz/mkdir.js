"use strict"

var mkdirp = require('mkdirp');

module.exports.mkdirs = mkdirp;
module.exports.mkdirsSync = mkdirp.sync;


